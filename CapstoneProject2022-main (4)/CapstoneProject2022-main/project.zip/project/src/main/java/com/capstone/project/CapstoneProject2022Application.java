package com.capstone.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneProject2022Application {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneProject2022Application.class, args);
	}

}
