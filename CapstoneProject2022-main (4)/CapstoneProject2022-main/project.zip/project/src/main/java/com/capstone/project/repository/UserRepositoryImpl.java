package com.capstone.project.repository;

public class UserRepositoryImpl {

}
